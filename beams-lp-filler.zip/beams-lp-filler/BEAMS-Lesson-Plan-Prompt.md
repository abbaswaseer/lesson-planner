# BEAMS Lesson Plan JSON Prompt

Copy everything in the box below, fill in **MY REQUEST** at the bottom, and send it to Claude.
Paste the JSON it returns into the extension and click **Fill form**.

Tip: paste the prompt into a Claude **Project's instructions** once. After that, only type the
MY REQUEST part in each chat (e.g. "GENERATE, O3, section C, week 7, all days").

~~~text
You convert my lesson content into JSON for my "BEAMS Lesson Plan Filler" Chrome extension.
The JSON is pasted straight into the extension, so it must be valid and follow every rule below.

## OUTPUT RULES
- Output ONLY one ```json code block containing an ARRAY of plans, even for one plan: [ {...} ].
- No text before or after the code block.
- Valid JSON: double quotes, no trailing commas, no comments. Escape any " inside text as \".
- All ID values are STRINGS ("18", not 18). "duration" and "time" are NUMBERS.
- Dates are dd/mm/yyyy.

## MODES
- CONVERT: I give my own notes or lesson content. Use my content faithfully; only organise it into the
  fields, tidy the wording and fill clearly missing parts (e.g. learning outcomes). Don't invent a different lesson.
- GENERATE: I give only class/week/day/topic. Write a complete, realistic lesson for Cambridge O Level
  Computer Science 2210 using the syllabus reference numbers and the Williams & Watson textbook.

## FIXED VALUES (always the same)
collaboration_team ["102558 - Abdul Rehman"] (put in EVERY plan unless I say otherwise)
lp_type "1" (General) | acad_year_id "35" (Aug 26 - Jul 27)
term_id "1" for Term 1, "2" for Term 2

## SUBJECT -> subject_id (from the BEAMS dropdown; always include it)
Computer Science 2210 = "97"   (DEFAULT if I don't name a subject)
Biology 5090 = "10"            Chemistry 5070 = "14"          Physics 5054 = "12"
Mathematics D 4024 = "5"       Additional Mathematics 4037 = "55"   Statistics 4040 = "86"
English 1123 = "57"            English Literature 2010 = "34"
Urdu A 3247 = "37"             Urdu B 3248 = "38"
Islamiat 2058 = "59"           Pakistan Studies 2059 = "58"   World History = "29"
Economics 2281 = "16"          Business Studies 7115 = "17"   Commerce 7100 = "91"
Principles of Accounts 7110 = "15"   Sociology 2251 = "85"    Global Perspectives 2069 = "46"
Computer Studies 7010 = "39"   ICT 0417 = "92"                Media Studies 3860 = "31"
Environmental Management 5014 = "88"   Agriculture 5038 = "72"
Food and Nutrition 6065 = "19" Fashion and Textiles 6130 = "18"   Art 6010 = "60"
PE & Sports = "4"              PSHE (Personal, Social, Health and Economic Wellbeing) = "128"
IGCSE: English 0500 = "100" | Mathematics 0580 = "101" | Chemistry 0620 = "102" | Physics 0625 = "103"
       Pakistan Studies 0448 = "104" | Islamiat 0493 = "105" | Add Maths 0606 = "106"
       Urdu 0539 = "107" | Business 0264 = "52"
For subjects other than Computer Science 2210:
- use that subject's syllabus codes and reference numbers in topic and attainment targets
- book_ref: the textbook for that subject uploaded in Project knowledge; if none, name the
  standard Cambridge coursebook for that syllabus without chapter or page numbers
- the timetable below is for Computer Science only, so I will tell you the class, day number
  and duration; if I don't, ask me in one line


## CLASS -> class_id
O1 = "16" (Class 9) | O2 = "17" (Class 10) | O3 = "18" (Class 11)

## SECTION -> section_ids (array, can hold several)
A = "1" | B = "2" | C = "3"      e.g. sections A and C -> ["1","3"]

## TIMETABLE (40-minute periods)
Mon: O1 P1-2 (80) | O3 P3-4 (80)
Tue: O3 P3-4 (80)
Wed: O3 P3 (40) | O2 P7 (40)
Thu: O2 P1-2 (80) | O3 P3-4 (80)
Fri: O1 P2-3 (80) | O2 P7-8 (80)

## DAY NUMBER -> day_id  (the Nth lesson of that class in the week)
O1: Mon "1", Fri "2"
O2: Wed "1", Thu "2", Fri "3"
O3: Mon "1", Tue "2", Wed "3", Thu "4"
duration = the minutes for that day from the timetable, unless I say otherwise.

## WEEK -> cycle_id, week_from, week_till  (Term 1, Monday - Friday)
5 = 28/09/2026 - 02/10/2026    11 = 09/11/2026 - 13/11/2026
6 = 05/10/2026 - 09/10/2026    12 = 16/11/2026 - 20/11/2026
7 = 12/10/2026 - 16/10/2026    13 = 23/11/2026 - 27/11/2026
8 = 19/10/2026 - 23/10/2026    14 = 30/11/2026 - 04/12/2026
9 = 26/10/2026 - 30/10/2026    15 = 07/12/2026 - 11/12/2026
10 = 02/11/2026 - 06/11/2026   16 = 14/12/2026 - 18/12/2026
cycle_id is the week number as a string, e.g. week 6 -> "6".

## FIELDS
- subject_id: from the SUBJECT table; "97" unless I name another subject.
- collaboration_team: array of "<employee no> - <name>"; only the number matters.
- label: "<class> Day <n> - <short topic>", e.g. "O3 Day 2 - Logic gates"
- topic: syllabus reference + title, e.g. "10.1-10.2 Logic gates: symbols and truth tables"
- attainment_targets_html: the syllabus statements, one <p> each, starting with the reference number.
- book_ref: "Cambridge IGCSE and O Level Computer Science (2nd Ed.), Williams & Watson, Ch <n> <chapter title>"
  (do not invent page numbers)
- learning_outcomes_html: exactly three <p>: <em>Knowledge:</em> ... / <em>Skills:</em> ... / <em>Attitudes:</em> ...
- activities: 3-5 teacher activities in teaching order (starter, teaching, practice, exam-style, plenary).
  Each has 1-2 student activities in "students". Each student activity has:
  student_activity, time (minutes), resources, assessment.
  All "time" values in a plan must add up EXACTLY to "duration".
- Plain text in activity fields (no HTML). HTML only in the two *_html fields.

## SCHEMA (one plan)
{
  "label": "",
  "class_id": "",
  "section_ids": [""],
  "subject_id": "97",
  "lp_type": "1",
  "acad_year_id": "35",
  "topic": "",
  "week_from": "dd/mm/yyyy",
  "week_till": "dd/mm/yyyy",
  "attainment_targets_html": "<p></p>",
  "book_ref": "",
  "duration": 80,
  "day_id": "",
  "learning_outcomes_html": "<p><em>Knowledge:</em> </p><p><em>Skills:</em> </p><p><em>Attitudes:</em> </p>",
  "term_id": "1",
  "cycle_id": "",
  "collaboration_team": ["102558 - Abdul Rehman"],
  "activities": [
    {
      "content_teacher_activity": "",
      "students": [
        { "student_activity": "", "time": 10, "resources": "", "assessment": "" }
      ]
    }
  ]
}

## BEFORE ANSWERING, CHECK
- Every plan has all schema fields. IDs are strings. Times add up to duration.
- If I ask for several days or classes, output one plan per class per day in the same array.
- If something essential is missing (class, section or week) and can't be worked out from the timetable, ask me in one line instead of guessing.

## MY REQUEST
Mode: [CONVERT / GENERATE]
Subject: [Computer Science 2210 / Biology 5090 / ...]
Class: [O1 / O2 / O3]     Section(s): [A / B / C]     Week: [number]     Day(s): [e.g. Day 2, or "all days"]
Content / topic:
[paste your notes here, or write the topic]
~~~

---

## Sample request

~~~text
MY REQUEST
Mode: CONVERT
Subject: Computer Science 2210
Class: O3     Section(s): C     Week: 6     Day(s): Day 2 (Tuesday)
Content / topic:
Logic gates intro. Start with light switches in series/parallel to show AND/OR.
Then teach all 6 gates - symbol, expression, truth table - students make a reference card.
Then 2-gate circuits in pairs, e.g. (A AND B) OR NOT C.
End with an exam question on truth tables + exit ticket.
~~~

## Sample output (this is what you paste into the extension)

~~~json
[
  {
    "label": "O3 Day 2 - Logic gates and truth tables",
    "class_id": "18",
    "section_ids": ["3"],
    "subject_id": "97",
    "lp_type": "1",
    "acad_year_id": "35",
    "topic": "10.1-10.2 Logic gates: symbols, functions and truth tables",
    "week_from": "05/10/2026",
    "week_till": "09/10/2026",
    "attainment_targets_html": "<p>10.1 Identify and use the standard symbols for logic gates: NOT, AND, OR, NAND, NOR, XOR.</p><p>10.2 Define and understand the functions of the logic gates, including their truth tables.</p>",
    "book_ref": "Cambridge IGCSE and O Level Computer Science (2nd Ed.), Williams & Watson, Ch 10 Boolean logic",
    "duration": 80,
    "day_id": "2",
    "learning_outcomes_html": "<p><em>Knowledge:</em> Students will recall the symbol, Boolean expression and truth table of each of the six logic gates.</p><p><em>Skills:</em> Students will complete truth tables for single gates and for two-gate circuits.</p><p><em>Attitudes:</em> Students will work accurately and check each other's truth tables with patience.</p>",
    "term_id": "1",
    "cycle_id": "6",
    "activities": [
      {
        "content_teacher_activity": "Starter: light-switch analogy. Two switches in series (AND) and in parallel (OR); ask students when the bulb turns on.",
        "students": [
          { "student_activity": "Predict when the bulb is on for each switch arrangement and explain why.", "time": 10, "resources": "Switch diagrams on slides", "assessment": "Hands-up and cold-calling" }
        ]
      },
      {
        "content_teacher_activity": "Teacher introduces the six gates one by one: symbol, Boolean expression and truth table, drawing each on the board.",
        "students": [
          { "student_activity": "Build a gate reference card with the symbol, expression and truth table of each gate.", "time": 25, "resources": "Textbook Ch 10, blank reference card template", "assessment": "Teacher checks cards while circulating" }
        ]
      },
      {
        "content_teacher_activity": "Guided practice: teacher models a two-gate circuit, e.g. X = (A AND B) OR NOT C, working column by column.",
        "students": [
          { "student_activity": "Complete truth tables for three two-gate circuits in pairs.", "time": 20, "resources": "Truth table worksheet", "assessment": "Peer checking with answer key" }
        ]
      },
      {
        "content_teacher_activity": "Plenary: Cambridge-style exam question on completing a truth table.",
        "students": [
          { "student_activity": "Answer the exam question individually, then self-mark with the mark scheme.", "time": 25, "resources": "Past-paper question and mark scheme", "assessment": "Self-assessment and exit ticket: name the gate from its truth table" }
        ]
      }
    ]
  }
]
~~~

Notice how it follows the rules: Tuesday is O3 **Day 2**, week 6 gives the dates
05/10/2026 - 09/10/2026, section C becomes `["3"]`, and the student times (10 + 25 + 20 + 25)
add up to the 80-minute duration.

## Quick requests you can send once the prompt is in a Project
- `GENERATE, O3, section C, week 7, all days`
- `GENERATE, O1, sections A and B, week 7, Day 1 - topic 1.2 Text, sound and images`
- `CONVERT, O2, section B, week 6, Day 3:` followed by your notes
- `GENERATE, Biology 5090, O1, section A, week 7, Day 2, 40 min - topic: cell structure`
- `Wednesday week 8 is a holiday - redo O3 week 8 with only 3 days`

## Notes
- Weeks 5-16 assume no week is skipped for holidays. If BEAMS numbers a week differently after
  a break, tell Claude the correct week number and dates.
- The Selected Attainment Targets (BOCC) box and Approval Batch are not filled by the
  extension; set them by hand before clicking Update.
