# BEAMS Lesson Plan Filler

## Install (once)
1. Unzip this folder somewhere permanent (e.g. Documents\beams-lp-filler).
2. Chrome -> chrome://extensions -> turn on Developer mode (top right).
3. Load unpacked -> choose this folder. Pin the extension to the toolbar.

## Use
1. In BEAMS open Lesson Plan -> add a NEW lesson plan (blank form).
2. Click the extension, paste the JSON from your Claude Project.
3. Pick the plan from the dropdown -> Fill form.
4. Check the log and the form, set Approval Batch if needed, click Update yourself.

The extension never clicks Update, and never touches Campus, Students,
Selected Attainment Targets, Approval Batch or Approving Authority.
Collaboration Team is filled only when the JSON has "collaboration_team".

## After changing any file
chrome://extensions -> click the reload icon on the extension.

## JSON format
See sample-plan.json. Activities can be flat
{ content_teacher_activity, student_activity, time, resources, assessment }
or nested with several student activities per teacher activity:
{ content_teacher_activity, students: [ { student_activity, time, resources, assessment } ] }
Plain text or HTML both work in text fields.
