const $ = id => document.getElementById(id);
let plans = [];
let done = [];

// Accepts a single plan, an array of plans, or { "plans": [...] }.
// Also strips ```json fences in case they get copied from the chat.
function parsePlans(text) {
  const t = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  if (!t) return [];
  const data = JSON.parse(t);
  if (Array.isArray(data)) return data;
  if (Array.isArray(data.plans)) return data.plans;
  return [data];
}

function planName(p, i) {
  return p.label || `${i + 1}. ${p.topic || 'Untitled plan'}`;
}

function render(keepIndex) {
  const sel = $('plan');
  const prev = keepIndex ?? sel.value;
  sel.innerHTML = '';
  const status = $('status');
  try {
    plans = parsePlans($('json').value);
    plans.forEach((p, i) => {
      const o = document.createElement('option');
      o.value = i;
      o.textContent = (done.includes(planName(p, i)) ? '✓ ' : '') + planName(p, i);
      sel.appendChild(o);
    });
    if (prev !== undefined && prev !== '' && +prev < plans.length) sel.value = prev;
    const need = ['class_id', 'section_ids', 'cycle_id', 'day_id', 'week_from', 'activities'];
    const wrong = plans.map((p, i) => [i + 1, need.filter(k => !(k in p))]).filter(([, m]) => m.length);
    if (wrong.length) {
      const [n, m] = wrong[0];
      status.textContent = `⚠ Plan ${n} is missing ${m.join(', ')}. This JSON isn't in BEAMS format; regenerate it in your BEAMS Lesson Plans Project.`;
      status.className = 'err';
    } else {
      status.textContent = plans.length ? `${plans.length} plan${plans.length > 1 ? 's' : ''} ready` : 'Paste JSON above';
      status.className = plans.length ? 'ok' : '';
    }
  } catch (e) {
    plans = [];
    status.textContent = 'This isn\u2019t valid JSON: ' + e.message;
    status.className = 'err';
  }
  $('fill').disabled = !plans.length;
}

function save() {
  chrome.storage.local.set({ lpJson: $('json').value, lpIndex: $('plan').value, lpDone: done });
}

function showLog(text) { $('log').textContent = text; }

$('json').addEventListener('input', () => { done = []; render(0); save(); });
$('plan').addEventListener('change', save);
$('clear').addEventListener('click', () => { $('json').value = ''; done = []; render(); showLog(''); save(); });

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Small check injected into the tab: is the (possibly reloaded) form ready?
function formReady() {
  const el = document.getElementById('attainment_targets');
  if (!el) return null;
  const jq = window.jQuery;
  return { ready: document.readyState === 'complete' && !!(jq && jq(el).data('summernote')) };
}

async function inject(tabId, func, args = []) {
  try {
    return await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, world: 'MAIN', func, args });
  } catch (e) {
    return null; // frame was reloading; caller retries
  }
}

async function waitForForm(tabId) {
  await sleep(1500);
  for (let t = 0; t < 30; t++) {
    const r = await inject(tabId, formReady);
    if (r && r.some(x => x && x.result && x.result.ready)) { await sleep(1200); return true; }
    await sleep(500);
  }
  return false;
}

$('fill').addEventListener('click', async () => {
  const i = +$('plan').value;
  const plan = plans[i];
  if (!plan) return;
  $('fill').disabled = true;
  const lines = [];
  showLog('Filling\u2026 keep this popup open.');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let finished = false;
    for (let pass = 1; pass <= 4 && !finished; pass++) {
      const results = await inject(tab.id, fillLessonPlan, [plan]);
      const hit = results && results.find(r => r && r.result && r.result.found);
      if (!hit) {
        if (pass === 1) { lines.push('❌ No lesson plan form found in this tab.\nOpen BEAMS \u2192 Lesson Plan \u2192 a new plan, then try again.'); break; }
        if (!(await waitForForm(tab.id))) { lines.push('❌ The form did not come back after reloading. Refresh BEAMS and try again.'); break; }
        continue;
      }
      lines.push(...hit.result.log);
      showLog(lines.join('\n'));
      if (hit.result.pending) {
        if (!(await waitForForm(tab.id))) { lines.push('❌ The form did not come back after reloading. Refresh BEAMS and try again.'); break; }
      } else {
        finished = true;
      }
    }
    showLog(lines.join('\n'));
    if (finished) {
      const name = planName(plan, i);
      if (!done.includes(name)) done.push(name);
      render(i);
      save();
    }
  } catch (e) {
    showLog('❌ ' + e.message + '\nMake sure the active tab is BEAMS.');
  } finally {
    $('fill').disabled = !plans.length;
  }
});

chrome.storage.local.get(['lpJson', 'lpIndex', 'lpDone'], d => {
  $('json').value = d.lpJson || '';
  done = d.lpDone || [];
  render(d.lpIndex);
});
