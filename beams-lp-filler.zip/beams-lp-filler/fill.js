// fillLessonPlan() is injected into every frame of the BEAMS tab with
// chrome.scripting.executeScript({ world: "MAIN" }). It must be fully
// self-contained (no outside variables) because Chrome serialises it.
// It only acts in the frame that contains the lesson plan form.

async function fillLessonPlan(plan) {
  const doc = document;
  if (!doc.getElementById('attainment_targets')) return { found: false };

  const jq = window.jQuery || window.$;
  const log = [];
  const ok = m => log.push('✅ ' + m);
  const bad = m => log.push('❌ ' + m);
  const info = m => log.push('ℹ️ ' + m);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  if (!jq) { bad('jQuery not found on this page'); return { found: true, log }; }

  // ---------- helpers ----------
  const has = v => v !== undefined && v !== null && String(v).trim() !== '';
  const pick = (...keys) => { for (const k of keys) if (has(plan[k])) return plan[k]; return undefined; };
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // Plain text becomes <p> lines; HTML is used as-is.
  const toHtml = v => {
    const s = String(v).trim();
    if (/<\/?[a-z][\s\S]*>/i.test(s)) return s;
    return s.split(/\n+/).map(l => `<p>${esc(l)}</p>`).join('');
  };
  const waitFor = async (fn, timeout = 6000) => {
    const t = Date.now();
    while (Date.now() - t < timeout) { if (fn()) return true; await sleep(150); }
    return false;
  };
  const today = () => {
    const d = new Date();
    return [d.getDate(), d.getMonth() + 1].map(n => String(n).padStart(2, '0')).join('/') + '/' + d.getFullYear();
  };

  // Chosen dropdowns (class "choosen_picker"): set value, fire change, refresh the widget.
  async function setChosen(id, value, label) {
    if (!has(value)) return;
    const el = doc.getElementById(id);
    if (!el) return bad(`${label}: #${id} not on page`);
    const vals = (Array.isArray(value) ? value : [value]).map(String);
    const ready = await waitFor(() => vals.every(v => [...el.options].some(o => o.value === v)));
    if (!ready) return bad(`${label}: option "${vals.join(', ')}" not available (page offers: ${[...el.options].filter(o => o.value).map(o => o.value + '=' + o.text.trim()).join(', ') || 'nothing yet'})`);
    jq(el).val(el.multiple ? vals : vals[0]).trigger('change').trigger('chosen:updated');
    ok(`${label}: ${[...el.selectedOptions].map(o => o.text.trim()).join(', ')}`);
  }

  function setText(id, value, label) {
    if (!has(value)) return;
    const el = doc.getElementById(id);
    if (!el) return bad(`${label}: #${id} not on page`);
    el.value = String(value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    jq(el).trigger('change');
    ok(`${label}: ${String(value).slice(0, 60)}`);
  }

  // Summernote editor. Also copies the text into the hidden textarea,
  // and (for activity popups) into the "Click here to add content" link,
  // exactly like BEAMS does when you close the popup.
  function setNote(id, value, btnId) {
    if (!has(value)) return null;
    const el = doc.getElementById(id);
    if (!el) return false;
    const html = toHtml(value);
    try { if (jq(el).data('summernote')) jq(el).summernote('code', html); } catch (e) { /* fall through */ }
    el.value = html;
    jq(el).trigger('change');
    if (btnId && typeof window.set_textarea_value === 'function') window.set_textarea_value(id, btnId);
    return true;
  }
  const mark = r => (r === true ? '✅' : r === false ? '❌' : '–');

  // ---------- 1. dropdowns (class first: it may reload the others) ----------
  const selects = [
    ['class_id', pick('class_id'), 'Class'],
    ['section_id', pick('section_ids', 'section_id'), 'Section'],
    ['subject_id', pick('subject_id') ?? '97', 'Subject'],
    ['lp_type', pick('lp_type') ?? '1', 'Type'],
    ['acad_year_id', pick('acad_year_id') ?? '35', 'Academic year'],
    ['day_id', pick('day_id'), 'Day'],
    ['term_id', pick('term_id'), 'Term'],
    ['cycle_id', pick('cycle_id'), 'Cycle / week']
  ];
  if (!has(plan.class_id)) bad('Class: no "class_id" in the JSON, so Subject and Section cannot load. Use JSON made with the Project instructions.');

  // Changing Class or Subject makes BEAMS reload the form, which wipes anything
  // filled before it. So: change ONE of them, stop, and let the popup call us
  // again once the reloaded form is ready. On the next pass they already match.
  for (const [id, v, label] of selects.slice(0, 3).filter(s => s[0] !== 'section_id')) {
    if (!has(v)) continue;
    const el = doc.getElementById(id);
    if (!el || el.value === String(v)) continue;
    const ready = await waitFor(() => [...el.options].some(o => o.value === String(v)));
    if (!ready) { bad(`${label}: option "${v}" not available`); continue; }
    jq(el).val(String(v)).trigger('chosen:updated').trigger('change');
    return { found: true, pending: true, log: [`⏳ ${label} set to ${el.selectedOptions[0]?.text.trim()}; waiting for BEAMS to reload the form…`] };
  }
  if (has(plan.class_id)) ok(`Class: ${doc.getElementById('class_id')?.selectedOptions[0]?.text.trim()}`);
  ok(`Subject: ${doc.getElementById('subject_id')?.selectedOptions[0]?.text.trim()}`);

  for (const [id, v, label] of selects) {
    if (id === 'class_id' || id === 'subject_id') continue;
    await setChosen(id, v, label);
  }

  // ---------- 1b. collaboration team (optional, Chosen multi-select) ----------
  // Accepts ["102558"] or ["102558 - Abdul Rehman"]; only the employee number is used.
  const collab = pick('collaboration_team', 'collaboration');
  if (has(collab)) {
    const el = doc.querySelector('select[name="collaboration[]"]');
    if (!el) bad('Collaboration: field not on page');
    else {
      const ids = (Array.isArray(collab) ? collab : [collab])
        .map(v => (String(v).match(/\d+/) || [])[0]).filter(Boolean);
      const missing = ids.filter(id => ![...el.options].some(o => o.value === id));
      const keep = ids.filter(id => !missing.includes(id));
      if (keep.length) {
        const cur = [...el.selectedOptions].map(o => o.value);
        jq(el).val([...new Set([...cur, ...keep])]).trigger('change').trigger('chosen:updated');
        ok('Collaboration: ' + keep.map(id => [...el.options].find(o => o.value === id).text.trim()).join(', '));
        await sleep(500);
      }
      if (missing.length) bad(`Collaboration: ${missing.join(', ')} not found in the staff list`);
    }
  }

  // ---------- 2. create activity rows (before filling any editor) ----------
  const acts = Array.isArray(plan.activities) ? plan.activities : [];
  const created = [];
  if (acts.length) {
    if (typeof window.add_activity !== 'function' || typeof window.add_std_activity_new !== 'function') {
      bad('Activity table functions not found — rows not added');
    } else {
      const existing = doc.querySelectorAll('textarea[id^="objective_"]').length;
      if (existing) info(`${existing} activity row(s) were already on the page; new rows were added after them`);
      for (const a of acts) {
        const before = new Set([...doc.querySelectorAll('textarea[id^="objective_"]')].map(e => e.id));
        window.add_activity(1);
        const ta = [...doc.querySelectorAll('textarea[id^="objective_"]')].find(e => !before.has(e.id));
        if (!ta) { bad('Could not add an activity row'); continue; }
        const N = ta.id.slice('objective_'.length);

        // Each teacher activity can hold one or more student activities.
        const students = Array.isArray(a.students) && a.students.length ? a.students : [a];
        const subs = [];
        for (const s of students) {
          const pre = `methodology_title_${N}_`;
          const b2 = new Set([...doc.querySelectorAll(`textarea[id^="${pre}"]`)].map(e => e.id));
          window.add_std_activity_new(Number(N), 1, 1, 1);
          const t = [...doc.querySelectorAll(`textarea[id^="${pre}"]`)].find(e => !b2.has(e.id));
          if (!t) { bad(`Could not add a student activity to row ${N}`); continue; }
          subs.push({ k: t.id.slice(pre.length), s });
        }
        created.push({ N, a, subs });
      }
      await sleep(800); // editors re-initialise after rows are added
    }
  }

  // ---------- 3. text fields and editors ----------
  setText('topic', pick('topic'), 'Topic');
  setText('creation_date', pick('creation_date') ?? today(), 'Creation date');
  setText('plan_to', pick('week_from'), 'Week from');   // BEAMS ids are swapped:
  setText('plan_from', pick('week_till'), 'Week till'); // plan_to = From, plan_from = Till
  setText('book_ref', pick('book_ref', 'book_reference'), 'Book reference');
  const digits = v => (has(v) ? (String(v).match(/\d+/) || [])[0] : undefined);
  setText('suggested_duration', digits(pick('duration', 'suggested_duration', 'duration_minutes')), 'Duration (minutes)');

  const at = setNote('attainment_targets', pick('attainment_targets_html', 'attainment_targets'));
  if (at !== null) (at ? ok : bad)('Attainment targets');
  const lo = setNote('learning_outcomes', pick('learning_outcomes_html', 'learning_outcomes'));
  if (lo !== null) (lo ? ok : bad)('Learning outcomes');

  created.forEach(({ N, a, subs }, i) => {
    const t = setNote(`objective_${N}`, a.content_teacher_activity ?? a.teacher_activity, `activity_btn_${N}`);
    const parts = subs.map(({ k, s }) => {
      const sa = setNote(`methodology_title_${N}_${k}`, s.student_activity, `methodology_title_btn_${N}_${k}`);
      const rs = setNote(`methodology_detail_${N}_${k}`, s.resources, `methodology_detail_btn_${N}_${k}`);
      const as = setNote(`methodology_assesment_${N}_${k}`, s.assessment, `methodology_assesment_btn_${N}_${k}`);
      const d = doc.querySelector(`input[name="duration_[${N}][${k}]"]`);
      let tm = null;
      if (d && has(s.time)) { d.value = (String(s.time).match(/\d+/) || ['20'])[0].slice(0, 3); jq(d).trigger('change'); tm = true; }
      else if (has(s.time)) tm = false;
      return `student ${mark(sa)} time ${mark(tm)}${tm ? ' ' + s.time + 'm' : ''} resources ${mark(rs)} assessment ${mark(as)}`;
    });
    log.push(`${t === false ? '❌' : '✅'} Activity ${i + 1}: teacher ${mark(t)} | ${parts.join(' | ')}`);
  });

  // ---------- 4. re-check dropdowns (AJAX reloads can reset them) ----------
  for (const [id, v, label] of selects) {
    if (!has(v)) continue;
    const el = doc.getElementById(id);
    if (!el) continue;
    const want = (Array.isArray(v) ? v : [v]).map(String);
    const cur = [...el.selectedOptions].map(o => o.value);
    if (want.some(w => !cur.includes(w)) && want.every(w => [...el.options].some(o => o.value === w))) {
      jq(el).val(el.multiple ? want : want[0]).trigger('chosen:updated');
      info(`${label} was reset by the page, so it was set again`);
    }
  }

  log.push('👀 Review the form, set Approval Batch if needed, then click Update yourself.');
  return { found: true, log };
}
